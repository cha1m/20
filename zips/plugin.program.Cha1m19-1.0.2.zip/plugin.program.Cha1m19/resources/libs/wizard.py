# coding: utf-8
################################################################################
#      Copyright (C) 2019 drinfernoo                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import xbmc
import xbmcgui,logging

import os
import urllib
from resources.libs import check
from resources.libs import db
from resources.libs import extract
from resources.libs import install
from resources.libs import skin
#from resources.libs.common import logging
from resources.libs.common import tools
from resources.libs.common.config import CONFIG
from resources.libs.downloader import Downloader

try:
    from urllib.request import urlopen
    from urllib.request import Request
except ImportError:
    from urllib2 import urlopen
    from urllib2 import Request


DP               = xbmcgui.DialogProgress()
dp               = xbmcgui.DialogProgress()
def chunk_report(bytes_so_far, chunk_size, total_size):
   percent = float(bytes_so_far) / total_size
   percent = round(percent*100, 2)

   # if bytes_so_far >= total_size:
      # sys.stdout.write('\n')

def chunk_read(response, chunk_size=8192, report_hook=None,dp=None,destination='',filesize=1000000):
   import time
   name='Chameleon Kodi'
   total_size = int(filesize)*1000000

   bytes_so_far = 0
   start_time = time.time()
   count=0
   zxz = '[COLOR %s][B][/B][/COLOR] [COLOR %s]%s v%s[/COLOR]' % ('blue', 'white', name,'')
   # logging.warning('Downloading')
   with open(destination, "wb") as f:
    while 1:
      duration = time.time() - start_time
      progress_size = int(count * chunk_size)
      chunk = response.read(chunk_size)
      f.write(chunk)
      f.flush()
      bytes_so_far += len(chunk)
      percent = float(bytes_so_far) / total_size
      percent = round(percent*100, 2)
      if int(duration)>0: 
        speed = int((progress_size)/ (1024 * duration))
      else:
         speed=0
      if speed > 1024 and not percent == 100:
          eta =int(( (total_size - progress_size)/1024) / (speed) )
      else:
          eta=0
      if eta<0:
        eta=0
      try:
        dp.update(int(percent),"[B]הורדה: [/B]"+zxz, "\r%d%%,[COLOR silver] %d MB / %d MB [/COLOR], %d KB/s " %(percent, progress_size / (1024 * 1024),total_size/(1000 * 1000), speed), '[B]זמן נותר:  [/B] [COLOR silver]%02d:%02d[/COLOR]' % divmod(eta, 60))
      except:
        dp.update(int(percent),"[B]הורדה: [/B]"+zxz+'\n'+ "\r%d%%,[COLOR yellow] %d MB / %d MB [/COLOR], %d KB/s " %(percent, progress_size / (1024 * 1024),total_size/(1000 * 1000), speed)+'\n'+ '[B]זמן נותר: [/B] [COLOR silver]%02d:%02d[/COLOR]' % divmod(eta, 60))
      if dp.iscanceled():
         dp.close()
         break
      if not chunk:
         break

      if report_hook:
         report_hook(bytes_so_far, chunk_size, total_size)
      count += 1
   # logging.warning('END Downloading')
   return bytes_so_far
def get_url_from_gdrive_confirmation(contents):
  

    import re
    url = ""
    for line in contents.splitlines():
        m = re.search(r'href="(\/uc\?export=download[^"]+)', line)
        if m:
            url = "https://docs.google.com" + m.groups()[0]
            url = url.replace("&amp;", "&")
            break
        m = re.search('id="download-form" action="(.+?)"', line)
        if m:
            url = m.groups()[0]
            url = url.replace("&amp;", "&")
            break
        m = re.search('"downloadUrl":"([^"]+)', line)
        if m:
            url = m.groups()[0]
            url = url.replace("\\u003d", "=")
            url = url.replace("\\u0026", "&")
            break
        m = re.search('<p class="uc-error-subcaption">(.*)</p>', line)
        if m:
            error = m.groups()[0]
            raise RuntimeError(error)
    if not url:
        raise RuntimeError(
            "Cannot retrieve the public link of the file. "
            "You may need to change the permission to "
            "'Anyone with the link', or have had many accesses."
        )
    return url
def googledrive_download(id, destination,dp,filesize):
    import urllib.request
    import sys
    import io,time
    id_pre=id.split('=')
    id=id_pre[len(id_pre)-1]
    headers = {
        'authority': 'drive.google.com',
        'content-length': '0',
        'cache-control': 'max-age=0',
        'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'upgrade-insecure-requests': '1',
        'origin': 'https://drive.google.com',
        'content-type': 'application/x-www-form-urlencoded',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document',
        'referer': 'https://drive.google.com/uc?id=%s&export=download'%id,
        'accept-language': 'he-IL,he;q=0.9',
    }
    headers = {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36"  # NOQA
    }
    url='https://drive.google.com/uc?id=%s&export=download&confirm=t'%id
    url='https://drive.google.com/uc?id='+id
    
   
    req = urllib.request.Request(url, headers=headers)
    resp = urllib.request.urlopen(req)
    
    url = get_url_from_gdrive_confirmation(resp.read().decode('utf-8'))
    
 
    
    req = urllib.request.Request(url, headers=headers)
    resp = urllib.request.urlopen(req)
    
    length = resp.getheader('content-length')
    if length:
        length = int(length)
        blocksize = max(4096, length//100)
    else:
        blocksize = 1000000 # just made something up

    

    buf = io.BytesIO()
    size = 0
    
    with open(destination, "wb") as f:
      count=1
      start_time = time.time()
      while 1:
        buf1 = resp.read(blocksize)
        if not buf1:
            break
        f.write(buf1)
        f.flush()
        size += len(buf1)
        duration = time.time() - start_time
        progress_size = int(count * blocksize)
        
        speed = int((progress_size)/ (1024 * duration))
        percent = int(count * blocksize * 100 / length)
        if speed > 1024 and not percent == 100:
          eta =int(( (length - progress_size)/1024) / (speed) )
        else:
          eta=0
        
        count+=1
        dp.update(int(percent), "\r%d%%,[COLOR salmon] %d MB / %d MB [/COLOR], %d KB/s " %(percent, progress_size / (1024 * 1024),length/(1000 * 1000), speed)+'\n'+ '[B]ETA:[/B] [COLOR salmon]%02d:%02d[/COLOR]' % divmod(eta, 60))
                    
        
            
            
            
        if dp.iscanceled():
         dp.close()
         break
     

        
    
    
    
                     
def googledrive_download_old(id, destination,dp,filesize):
    #download('http://mirrors.kodi.tv/addons/jarvis/script.module.requests/script.module.requests-2.9.1.zip','script.module.requests')
    #dis_or_enable_addon('script.module.requests','auto')
    #import requests,time
    keys=[]
    id_pre=id.split('=')
    id=id_pre[len(id_pre)-1]

    def get_confirm_token(response):
        logging.warning('response:')
        logging.warning(response)
        for cookie in response:
            # logging.warning('cookie.name')
            # logging.warning(cookie.name)
            backup_cookie= cookie.value
            if 'download_warning' in cookie.name:
                # logging.warning(cookie.value)
                # logging.warning('cookie.value')
                return cookie.value
            return backup_cookie

        return None

    def save_response_content(response, destination):
        
        CHUNK_SIZE = 32768
        start_time = time.time()
     
        with open(destination, "wb") as f:
            count = 1
            block_size = 32768
            try:
                total_size = int(response.headers.get('content-length'))
                print(('file total size :',total_size))
            except TypeError:
                print ('using dummy length !!!')
                total_size = int(filesize)*1000000
            for chunk in response.iter_content(CHUNK_SIZE):
                if chunk: # filter out keep-alive new chunks
                    f.write(chunk)
                    f.flush()
                    duration = time.time() - start_time
                    progress_size = int(count * block_size)
                    if duration == 0:
                        duration = 0.1
                    speed = int((progress_size)/ (1024 * duration))
                    percent = int(count * block_size * 100 / total_size)
                    if speed > 1024 and not percent == 100:
                      eta =int(( (total_size - progress_size)/1024) / (speed) )
                    else:
                      eta=0
                    #sys.stdout.write("\r...%d%%, %d MB, %d KB/s, %d seconds passed" %(percent, progress_size / (1024 * 1024), speed, duration))
                    dp.update(int(percent),name, "\r%d%%,[COLOR salmon] %d MB / %d MB [/COLOR], %d KB/s " %(percent, progress_size / (1024 * 1024),total_size/(1000 * 1000), speed), '[B]ETA:[/B] [COLOR salmon]%02d:%02d[/COLOR]' % divmod(eta, 60))
                    count += 1
                    if dp.iscanceled():
                     dp.close()
                     break
    URL = "https://docs.google.com/uc?export=download"

    #session = requests.Session()

    #response = session.get(URL, params = { 'id' : id }, stream = True)
    try:
        import urllib2
        import cookielib
        from cookielib import CookieJar
        
    except:
        import http.cookiejar
        from urllib.request import urlopen
        from urllib.request import Request
        
        
    try:
        cookjar = CookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookjar))
    except:
        cookielib = http.cookiejar
        cookjar = cookielib.CookieJar()
        handlers = [urllib.request.HTTPCookieProcessor(cookjar),urllib.request.HTTPHandler(), urllib.request.HTTPSHandler()]
        opener = urllib.request.build_opener(*handlers)
    
    # input-type values from the html form
    formdata =  { 'id' : id }
    try:
       data_encoded = urllib.urlencode(formdata)
    except:
       data_encoded = urllib.parse.urlencode(formdata)
    response = opener.open(URL+'&'+ data_encoded)
    
    content = response.read()
    logging.warning(URL+'&'+ data_encoded)
    for cookie in cookjar:
     try:
          logging.warning( cookie)
     except:pass
    token = get_confirm_token(cookjar)

    if token:
        params = { 'id' : id, 'confirm' : token }
        headers = {'Access-Control-Allow-Headers': 'Content-Length'}
        try:
          data_encoded = urllib.urlencode(params)
        except:
          data_encoded = urllib.parse.urlencode(params)
        response = opener.open(URL+'&'+ data_encoded)
        chunk_read(response, report_hook=chunk_report,dp=dp,destination=destination,filesize=filesize)
        

    #save_response_content(response, destination)
    return(keys)
class Wizard:

    def __init__(self):
        tools.ensure_folders(CONFIG.PACKAGES)
        
        self.dialog = xbmcgui.Dialog()
        self.dialogProgress = xbmcgui.DialogProgress()

    def _prompt_for_wipe(self):
        # Should we wipe first?
        if self.dialog.yesno(CONFIG.ADDONTITLE,
                           "[COLOR {0}]Do you wish to restore your".format(CONFIG.COLOR2) +'\n' + "Kodi configuration to default settings" + '\n' + "Before installing the build backup?[/COLOR]",
                           nolabel='[B][COLOR red]No[/COLOR][/B]',
                           yeslabel='[B][COLOR springgreen]Yes[/COLOR][/B]'):
            install.wipe()

    def build(self, name, over=False):
        # if action == 'normal':
            # if CONFIG.KEEPTRAKT == 'true':
                # from resources.libs import traktit
                # traktit.auto_update('all')
                # CONFIG.set_setting('traktnextsave', tools.get_date(days=3, formatted=True))
            # if CONFIG.KEEPDEBRID == 'true':
                # from resources.libs import debridit
                # debridit.auto_update('all')
                # CONFIG.set_setting('debridnextsave', tools.get_date(days=3, formatted=True))
            # if CONFIG.KEEPLOGIN == 'true':
                # from resources.libs import loginit
                # loginit.auto_update('all')
                # CONFIG.set_setting('loginnextsave', tools.get_date(days=3, formatted=True))

        temp_kodiv = int(CONFIG.KODIV)
        buildv = int(float(check.check_build(name, 'kodi')))

        if not temp_kodiv == buildv:
            warning = True
        else:
            warning = False

        if warning:
            yes_pressed = self.dialog.yesno("{0} - [COLOR red]WARNING!![/COLOR]".format(CONFIG.ADDONTITLE), '[COLOR {0}]There is a chance that the skin will not appear correctly'.format(CONFIG.COLOR2) + '\n' + 'When installing a {0} build on a Kodi {1} install'.format(check.check_build(name, 'kodi'), CONFIG.KODIV) + '\n' + 'Would you still like to install: [COLOR {0}]{1} v{2}[/COLOR]?[/COLOR]'.format(CONFIG.COLOR1, name, check.check_build(name, 'version')), nolabel='[B][COLOR red]No, Cancel[/COLOR][/B]', yeslabel='[B][COLOR springgreen]Yes, Install[/COLOR][/B]')
        else:
            if over:
                yes_pressed = 1
            else:
                yes_pressed = self.dialog.yesno(CONFIG.ADDONTITLE, '[COLOR {0}]האם להתחיל בהורדה והתקנה '.format(CONFIG.COLOR2) + '[COLOR {0}]{1} v{2}[/COLOR]?[/COLOR]'.format(CONFIG.COLOR1, name, check.check_build(name,'version')), nolabel='[B][COLOR red]ביטול[/COLOR][/B]', yeslabel='[B][COLOR springgreen]התקנה[/COLOR][/B]')
        if yes_pressed:
            logging.warning('Started')
            install.wipe()
            CONFIG.clear_setting('build')
            buildzip = check.check_build(name, 'url')
            zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')

            self.dialogProgress.create(CONFIG.ADDONTITLE, '[COLOR {0}][B]Downloading:[/B][/COLOR] [COLOR {1}]{2} v{3}[/COLOR]'.format(CONFIG.COLOR2, CONFIG.COLOR1, name, check.check_build(name, 'version')) + '\n' + 'Please Wait')

            lib = os.path.join(CONFIG.MYBUILDS, '{0}.zip'.format(zipname))
            DP.create('מתקין',name)
            try:
                os.remove(lib)
            except:
                pass
            logging.warning(buildzip)
            if 'google' in buildzip:

               res=googledrive_download(buildzip, lib, DP,'170')
            else:
                Downloader().download(buildzip, lib)
                xbmc.sleep(500)
            
            if os.path.getsize(lib) == 0:
                try:
                    os.remove(lib)
                except:
                    pass
                    
                return
                
            # yes_fresh = self.dialog.yesno(CONFIG.ADDONTITLE,
                                       # '[COLOR {0}][COLOR {1}]שים לב: כל המידע הקודם ימחק!- האם להמשיך?[/COLOR]'.format(CONFIG.COLOR2, CONFIG.COLOR1),
                                       # nolabel='[B][COLOR red]לא[/COLOR][/B]',
                                       # yeslabel='[B][COLOR springgreen]המשך התקנה[/COLOR][/B]')
            # if yes_fresh:
            # install.wipe()
                
            # skin.look_and_feel_data('save')
            
            title = '[COLOR {0}][B]מתקין: [/B][/COLOR] [COLOR {1}]{2} v{3}[/COLOR]'.format(CONFIG.COLOR2, CONFIG.COLOR1, name, check.check_build(name, 'version'))
            self.dialogProgress.update(0, title + '\n' + 'Please Wait')
            percent, errors, error = extract.all(lib, CONFIG.HOME, title=title)
            
            skin.skin_to_default('Build Install')

            if int(float(percent)) > 0:
                db.fix_metas()
                CONFIG.set_setting('buildname', name)
                CONFIG.set_setting('buildversion', check.check_build(name, 'version'))
                CONFIG.set_setting('buildtheme', '')
                CONFIG.set_setting('latestversion', check.check_build(name, 'version'))
                CONFIG.set_setting('nextbuildcheck', tools.get_date(days=CONFIG.UPDATECHECK, formatted=True))
                CONFIG.set_setting('installed', 'true')
                CONFIG.set_setting('extract', percent)
                CONFIG.set_setting('errors', errors)
                #logging.log('INSTALLED {0}: [ERRORS:{1}]'.format(percent, errors))

                try:
                    os.remove(lib)
                except:
                    pass

                if int(float(errors)) > 0:
                    yes_pressed = self.dialog.yesno(CONFIG.ADDONTITLE,
                                       '[COLOR {0}][COLOR {1}]{2} v{3}[/COLOR]'.format(CONFIG.COLOR2, CONFIG.COLOR1, name, check.check_build(name, 'version')) +'\n' + 'הושלם: [COLOR {0}]{1}{2}[/COLOR] [שגיאות:[COLOR {3}]{4}[/COLOR]]'.format(CONFIG.COLOR1, percent, '%', CONFIG.COLOR1, errors) + '\n' + 'האם ברצונך לצפות בשגיאות?[/COLOR]',
                                       nolabel='[B][COLOR red]לא[/COLOR][/B]',
                                       yeslabel='[B][COLOR springgreen]כן[/COLOR][/B]')
                    if yes_pressed:
                        from resources.libs.gui import window
                        window.show_text_box("Viewing Build Install Errors", error)
                self.dialogProgress.close()

                from resources.libs.gui.build_menu import BuildMenu
                #themecount = BuildMenu().theme_count(name)

                #if themecount > 0:
                    #self.theme(name, 'theme')

                db.addon_database(CONFIG.ADDON_ID, 1)
                #db.force_check_updates(over=True)

                self.dialog.ok(CONFIG.ADDONTITLE, "[COLOR {0}]קודי קמיליון הותקן בהצלחה! לחץ אישור לסגירה[/COLOR]".format(CONFIG.COLOR2))
                tools.kill_kodi(over=True)
            else:
                from resources.libs.gui import window
                window.show_text_box("צפיה בשגיאות בהתקנה", error)
        else:
            logging.log_notify(CONFIG.ADDONTITLE,
                               '[COLOR {0}]התקנת הבילד: בוטלה![/COLOR]'.format(CONFIG.COLOR2))

    def gui(self, name, over=False):
        if name == CONFIG.get_setting('buildname'):
            if over:
                yes_pressed = 1
            else:
                yes_pressed = self.dialog.yesno(CONFIG.ADDONTITLE,
                                   '[COLOR {0}]האם להמשיך בביצוע עדכון מהיר עובר: '.format(CONFIG.COLOR2) + '\n' + '[COLOR {0}]{1}[/COLOR]?[/COLOR]'.format(CONFIG.COLOR1, name),
                                   nolabel='[B][COLOR red]ביטול[/COLOR][/B]',
                                   yeslabel='[B][COLOR springgreen]בצע עדכון[/COLOR][/B]')
        else:
            yes_pressed = self.dialog.yesno("{0} - [COLOR red]WARNING!![/COLOR]".format(CONFIG.ADDONTITLE),
                               "[COLOR {0}][COLOR {1}]{2}[/COLOR] לא זוהה בילד נוכחי מותקן.".format(CONFIG.COLOR2, CONFIG.COLOR1, name) + '\n' + "האם להמשיך בביצוע העדכון המהיר?[/COLOR]",
                               nolabel='[B][COLOR red]ביטול[/COLOR][/B]',
                               yeslabel='[B][COLOR springgreen]בצע עדכון[/COLOR][/B]')
        if yes_pressed:
            guizip = check.check_build(name, 'gui')
            zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')

            response = tools.open_url(guizip, check=True)
            if not response:
                logging.log_notify(CONFIG.ADDONTITLE,
                                   '[COLOR {0}]GuiFix: Invalid Zip Url![/COLOR]'.format(CONFIG.COLOR2))
                return

            self.dialogProgress.create(CONFIG.ADDONTITLE, '[COLOR {0}][B]Downloading GuiFix:[/B][/COLOR] [COLOR {1}]{2}[/COLOR]'.format(CONFIG.COLOR2, CONFIG.COLOR1, name))

            lib = os.path.join(CONFIG.PACKAGES, '{0}_guisettings.zip'.format(zipname))
            
            try:
                os.remove(lib)
            except:
                pass

            Downloader().download(guizip, lib)
            xbmc.sleep(500)
            
            if os.path.getsize(lib) == 0:
                try:
                    os.remove(lib)
                except:
                    pass
                    
                return
            
            title = '[COLOR {0}][B]Installing:[/B][/COLOR] [COLOR {1}]{2}[/COLOR]'.format(CONFIG.COLOR2, CONFIG.COLOR1, name)
            self.dialogProgress.update(0, title + '\n' + 'Please Wait')
            extract.all(lib, CONFIG.USERDATA, title=title)
            self.dialogProgress.close()
            skin.skin_to_default('Build Install')
            skin.look_and_feel_data('save')
            installed = db.grab_addons(lib)
            db.addon_database(installed, 1, True)

            self.dialog.ok(CONFIG.ADDONTITLE, "[COLOR {0}]לשמירת השינויים יש לסגור את הקודי- אנא אשר[/COLOR]".format(CONFIG.COLOR2))
            tools.kill_kodi(over=True)
        else:
            logging.log_notify(CONFIG.ADDONTITLE,
                               '[COLOR {0}]GuiFix: Cancelled![/COLOR]'.format(CONFIG.COLOR2))

    def theme(self, name, theme, over=False):
        installtheme = False

        if not theme:
            themefile = check.check_build(name, 'theme')

            response = tools.open_url(themefile, check=True)
            if response:
                from resources.libs.gui.build_menu import BuildMenu
                themes = BuildMenu().theme_count(name, False)
                if len(themes) > 0:
                    if self.dialog.yesno(CONFIG.ADDONTITLE, "[COLOR {0}]The Build [COLOR {1}]{2}[/COLOR] comes with [COLOR {3}]{4}[/COLOR] different themes".format(CONFIG.COLOR2, CONFIG.COLOR1, name, CONFIG.COLOR1, len(themes)) + '\n' + "Would you like to install one now?[/COLOR]",
                                    yeslabel="[B][COLOR springgreen]Install Theme[/COLOR][/B]",
                                    nolabel="[B][COLOR red]Cancel Themes[/COLOR][/B]"):
                        logging.log("Theme List: {0}".format(str(themes)))
                        ret = self.dialog.select(CONFIG.ADDONTITLE, themes)
                        logging.log("Theme install selected: {0}".format(ret))
                        if not ret == -1:
                            theme = themes[ret]
                            installtheme = True
                        else:
                            logging.log_notify(CONFIG.ADDONTITLE,
                                               '[COLOR {0}]Theme Install: Cancelled![/COLOR]'.format(CONFIG.COLOR2))
                            return
                    else:
                        logging.log_notify(CONFIG.ADDONTITLE,
                                           '[COLOR {0}]Theme Install: Cancelled![/COLOR]'.format(CONFIG.COLOR2))
                        return
            else:
                logging.log_notify(CONFIG.ADDONTITLE,
                                   '[COLOR {0}]Theme Install: None Found![/COLOR]'.format(CONFIG.COLOR2))
        else:
            installtheme = self.dialog.yesno(CONFIG.ADDONTITLE, '[COLOR {0}]Would you like to install the theme:'.format(CONFIG.COLOR2) +' \n' + '[COLOR {0}]{1}[/COLOR]'.format(CONFIG.COLOR1, theme) + '\n' + 'for [COLOR {0}]{1} v{2}[/COLOR]?[/COLOR]'.format(CONFIG.COLOR1, name, check.check_build(name,'version')),yeslabel="[B][COLOR springgreen]Install Theme[/COLOR][/B]", nolabel="[B][COLOR red]Cancel Themes[/COLOR][/B]")
                                        
        if installtheme:
            themezip = check.check_theme(name, theme, 'url')
            zipname = name.replace('\\', '').replace('/', '').replace(':', '').replace('*', '').replace('?', '').replace('"', '').replace('<', '').replace('>', '').replace('|', '')

            response = tools.open_url(themezip, check=True)
            if not response:
                logging.log_notify(CONFIG.ADDONTITLE,
                                   '[COLOR {0}]Theme Install: Invalid Zip Url![/COLOR]'.format(CONFIG.COLOR2))
                return False

            self.dialogProgress.create(CONFIG.ADDONTITLE, '[COLOR {0}][B]Downloading:[/B][/COLOR] [COLOR {1}]{2}[/COLOR]'.format(CONFIG.COLOR2, CONFIG.COLOR1, zipname) +' \n' + 'Please Wait')

            lib = os.path.join(CONFIG.PACKAGES, '{0}.zip'.format(zipname))
            
            try:
                os.remove(lib)
            except:
                pass

            Downloader().download(themezip, lib)
            xbmc.sleep(500)
            
            if os.path.getsize(lib) == 0:
                try:
                    os.remove(lib)
                except:
                    pass
                    
                return
            
            self.dialogProgress.update(0, '\n' + "Installing {0}".format(name))

            title = '[COLOR {0}][B]Installing Theme:[/B][/COLOR] [COLOR {1}]{2}[/COLOR]'.format(CONFIG.COLOR2, CONFIG.COLOR1, theme)
            self.dialogProgress.update(0, title + '\n' + 'Please Wait')
            percent, errors, error = extract.all(lib, CONFIG.HOME, title=title)
            CONFIG.set_setting('buildtheme', theme)
            logging.log('INSTALLED {0}: [ERRORS:{1}]'.format(percent, errors))
            self.dialogProgress.close()

            #db.force_check_updates(over=True)
            installed = db.grab_addons(lib)
            db.addon_database(installed, 1, True)
            xbmc.executebuiltin("ReloadSkin()")
            xbmc.sleep(1000)
            xbmc.executebuiltin("Container.Refresh()")
        else:
            logging.log_notify(CONFIG.ADDONTITLE,
                               '[COLOR {0}]Theme Install: Cancelled![/COLOR]'.format(CONFIG.COLOR2))


def wizard(action, name, url):
    cls = Wizard()

    if action in ['fresh', 'normal']:
        cls.build(action, name)
    elif action == 'gui':
        cls.gui(name)
    elif action == 'theme':
        cls.theme(name, url)
